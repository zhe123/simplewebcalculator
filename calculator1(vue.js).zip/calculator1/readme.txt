/*
  author:Zhemou Li
  start date:7/1/2018
  end date:7/3/2018
  project:my calculator app
  
*/
description:
this project is to write a simple and basic web page calculator.
in files,the app is on INDEX1.HTML,
the CAL1.JS is to implement the calculation process.
the CAL1.CSS is to style the calculator.

update:
i used vue.js to re-write the calculator,and implement the contact form submission bonus which is to send the contact form through email with php mail() function.
.the new calvue.js is implemented with vue.js.
.the php file is mailhandling.php.

Test:
i used xampp as local web server to run the calulator html page,and used a simple smtp server implemented by a guy in github(link:https://github.com/ChangemakerStudios/Papercut)to test the e-mail sending,the e-mail is successfully sent and the calculation result is responded in the page
